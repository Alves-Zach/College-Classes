#include <iostream>

using namespace std;

int main() {

  cout << "2, 1 to call the electritian, 1 to yell at the electritian for not going fast enough\n";

}
